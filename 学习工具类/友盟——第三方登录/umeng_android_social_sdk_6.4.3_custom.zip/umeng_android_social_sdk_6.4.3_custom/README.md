#文件夹介绍：
main————为核心包，必须添加
platforms————为平台包，是您选择的各个平台的jar和资源
shareboard————分享面板包，如果不使用，可以不拷贝
shareview————分享编辑页，如果没有使用新浪精简版，豆瓣人人腾讯微博，可以不使用该文件夹
social_sdk_example————eclipse demo工程
social_sdk_example_as————android studio工程
umeng_integrate_tool————集成工具

更多工程配置和集成帮助可以点击http://dev.umeng.com/social/android/quick-integration
如遇问题，请查看线上报错必看文档