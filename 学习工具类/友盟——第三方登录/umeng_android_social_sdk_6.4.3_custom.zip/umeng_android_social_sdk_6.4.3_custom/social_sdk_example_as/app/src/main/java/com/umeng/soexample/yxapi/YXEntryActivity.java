
package com.umeng.soexample.yxapi;


import com.umeng.socialize.activity.YXCallbackActivity;

public class YXEntryActivity extends YXCallbackActivity {

}
