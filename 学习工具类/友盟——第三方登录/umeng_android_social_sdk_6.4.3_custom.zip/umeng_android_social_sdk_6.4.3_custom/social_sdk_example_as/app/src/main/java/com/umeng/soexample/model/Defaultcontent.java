package com.umeng.soexample.model;



/**
 * Created by wangfei on 16/7/12.
 */
public class Defaultcontent {
//   public static String url = "http://mobile.umeng.com/social";
    public static String url ="https://pano.autohome.com.cn/car/aa/web/?src=share";
    public static String text = "欢迎使用【友盟+】社会化组件U-Share，SDK包最小，集成成本最低，助力您的产品开发、运营与推广";
    public static String title = "【友盟+】社会化组件U-Share";
    public static String imageurl = "https://mobile.umeng.com/images/pic/home/social/img-1.png";
//     public static String imageurl = "https://img.dawuhanmedia.com/liveimg/41/1490773976999103661055569.jpg";
    public static String videourl = "http://video.sina.com.cn/p/sports/cba/v/2013-10-22/144463050817.html";
    public static String musicurl = "http://music.huoxing.com/upload/20130330/1364651263157_1085.mp3";

}
