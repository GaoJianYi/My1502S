package com.umeng.soexample.ddshare;


import com.umeng.socialize.media.DingCallBack;

/**
 * Created by hanhanliu on 15/12/9.
 */
public class DDShareActivity extends DingCallBack {


}
