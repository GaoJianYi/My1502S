package com.brioal.baselib.interfaces;

/**判断一条关注信息是否存在
 * Created by Brioal on 2016/6/7.
 */
public interface onCheckExitListener {
    void exit(String attentionId);

    void noExit();
}
