package com.brioal.baselib.interfaces;

/**
 * 列表加载更多的事件监听
 * Created by Brioal on 2016/5/24.
 */

public interface OnLoaderMoreListener {
    void loadMore();
}
