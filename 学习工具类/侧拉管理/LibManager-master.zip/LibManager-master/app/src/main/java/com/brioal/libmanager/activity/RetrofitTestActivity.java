package com.brioal.libmanager.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.brioal.libmanager.R;


public class RetrofitTestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_retrofit_test);
    }
}
