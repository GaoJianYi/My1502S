package com.brioal.rxlearnapp.activity;

import android.os.Bundle;

import com.brioal.baselib.base.BaseActivity;
import com.brioal.rxlearnapp.R;

public class MainActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_main);
    }
}
