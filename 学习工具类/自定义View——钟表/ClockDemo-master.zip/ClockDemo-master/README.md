# ClockDemo
自定义钟表View

[简书地址](http://www.jianshu.com/p/6414fdab1386)

![](http://upload-images.jianshu.io/upload_images/2352140-88d899a450d76ff4.gif)
